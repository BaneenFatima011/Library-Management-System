/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UnsupportedLookAndFeelException;
/**
 *
 * @author sunil
 */
public class ReturnBook extends javax.swing.JFrame {

    /**
     * Creates new form IssueBook
     */
    public ReturnBook() {
        initComponents();
    }

    public boolean updateBookStatusToIn() {
        Boolean isUpdated=false;
          String bookId = "B"+
                txt_bookId.getText();
        int studentId = Integer.parseInt(txt_studentId.getText());


    try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "abc123")) {
        String sql = "UPDATE HR1.ISSUED_BOOKS SET STATUS = 'In' WHERE BOOK_ID = ? AND STUDENT_ID = ? AND STATUS = 'OUT'";
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, bookId);
            pst.setInt(2, studentId);

            int rowCount = pst.executeUpdate();

            if (rowCount > 0) {
                isUpdated = true;
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return isUpdated;
}
    //to fetch the issue book details  from the database and display it to panel
    public void getIssueBookDetails() {
    String bookId = "B" + txt_bookId.getText();
    int studentId = Integer.parseInt(txt_studentId.getText());

    try {
        Class.forName("oracle.jdbc.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);

        // Check if the due date is greater than the current date
        String checkDueDateSql = "SELECT * FROM HR1.ISSUED_BOOKS WHERE BOOK_ID = ? AND STUDENT_ID = ? AND STATUS = 'OUT' ";
        try (PreparedStatement checkDueDatePst = con.prepareStatement(checkDueDateSql)) {
            checkDueDatePst.setString(1, bookId);
            checkDueDatePst.setInt(2, studentId);
           

          try (ResultSet dueDateRs = checkDueDatePst.executeQuery()) {
             
                if (dueDateRs.next()) {
                    // Retrieve RETURN_DATE from the result set
                    LocalDate returnDate = dueDateRs.getDate("RETURN_DATE").toLocalDate();

                    // Check if the return date is greater than the current date
                    if (returnDate.isBefore(LocalDate.now())) {
                    // If the due date is greater than the current date, join with the TRANSACTION table
                    String sql = "SELECT I.ISSUED_ID, B.BOOK_NAME, T.ARREARS, S.FIRST_NAME, I.ISSUE_DATE, I.RETURN_DATE FROM HR1.ISSUED_BOOKS I " +
                            "JOIN HR1.BOOKS B ON B.BOOK_ID=I.BOOK_ID " +
                            "JOIN HR1.STUDENT S ON S.STUDENT_ID=I.STUDENT_ID " +
                            "JOIN HR1.TRANSACTION T ON T.ISSUE_ID=I.ISSUED_ID " +
                            "WHERE I.BOOK_ID = ? AND I.STUDENT_ID = ? AND I.STATUS = 'OUT'";
                    try (PreparedStatement pst = con.prepareStatement(sql)) {
                        pst.setString(1, bookId);
                        pst.setInt(2, studentId);

                        try (ResultSet rs = pst.executeQuery()) {
                            if (rs.next()) {
                                lbl_issueId.setText(rs.getString("ISSUED_ID"));
                                lbl_bookName.setText(rs.getString("book_name"));
                                lbl_studentName.setText(rs.getString("first_name"));
                                lbl_issueDate.setText(rs.getString("issue_date"));
                                lbl_dueDate.setText(rs.getString("return_date"));
                                lbl_arrears.setText(rs.getString("ARREARS"));
                                lbl_bookError.setText("");
                            } else {
                                  System.out.println("udherbeee");
                                
                                lbl_bookError.setText("No Record Found");
                                lbl_issueId.setText("");
                                lbl_bookName.setText("");
                                lbl_studentName.setText("");
                                lbl_issueDate.setText("");
                                lbl_arrears.setText("");
                                lbl_dueDate.setText("");
                            }
                        }
                    }}
                 else {
                    // If the due date is not greater than the current date, use a different query
                    String sqlWithoutTransaction = "SELECT I.ISSUED_ID, B.BOOK_NAME, S.FIRST_NAME, I.ISSUE_DATE, I.RETURN_DATE " +
                            "FROM HR1.ISSUED_BOOKS I JOIN HR1.BOOKS B ON B.BOOK_ID=I.BOOK_ID " +
                            "JOIN HR1.STUDENT S ON S.STUDENT_ID=I.STUDENT_ID " +
                            "WHERE I.BOOK_ID = ? AND I.STUDENT_ID = ? AND I.STATUS = 'OUT'";
                    try (PreparedStatement pstWithoutTransaction = con.prepareStatement(sqlWithoutTransaction)) {
                        pstWithoutTransaction.setString(1, bookId);
                        pstWithoutTransaction.setInt(2, studentId);
System.out.println("isme");
                        try (ResultSet rsWithoutTransaction = pstWithoutTransaction.executeQuery()) {
                            if (rsWithoutTransaction.next()) {
                                
                                lbl_issueId.setText(rsWithoutTransaction.getString("ISSUED_ID"));
                                lbl_bookName.setText(rsWithoutTransaction.getString("book_name"));
                                lbl_studentName.setText(rsWithoutTransaction.getString("first_name"));
                                lbl_issueDate.setText(rsWithoutTransaction.getString("issue_date"));
                                lbl_dueDate.setText(rsWithoutTransaction.getString("return_date"));
                                lbl_arrears.setText(""); // No ARREARS in this case
                                lbl_bookError.setText("");
                            } 
                            else {
                                 
                                lbl_bookError.setText("No Record Found");
                                lbl_issueId.setText("");
                                lbl_bookName.setText("");
                                lbl_studentName.setText("");
                                lbl_issueDate.setText("");
                                lbl_arrears.setText("");
                                lbl_dueDate.setText("");
                            }
                        }
                    }
                }
                }
                else{
                    lbl_bookError.setText("No Record Found");
                                lbl_issueId.setText("");
                                lbl_bookName.setText("");
                                lbl_studentName.setText("");
                                lbl_issueDate.setText("");
                                lbl_arrears.setText("");
                                lbl_dueDate.setText("");
                }
               
        }
        }
       
    } catch (Exception e) {
        e.printStackTrace();
    }
      
}

        void updateArrears(Connection con, String bookId, int studentId, int newAmount) {
    try {
        String updateSql = "UPDATE hr1.TRANSACTION SET ARREARS = ? WHERE ISSUE_ID = ? AND STUDENT_ID = ?";
        try (PreparedStatement updatePst = con.prepareStatement(updateSql)) {
            updatePst.setInt(1, newAmount);
            updatePst.setString(2, bookId);
            updatePst.setInt(3, studentId);

            int rowsUpdated = updatePst.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Arrears updated successfully in TRANSACTION table.");
            } else {
                System.out.println("No rows updated in TRANSACTION table.");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
      Boolean UpdateStatus(){
           boolean isupt = false;
           int arr=0;
           String bookId = "B" + txt_bookId.getText();
    int studentId = Integer.parseInt(txt_studentId.getText());
    int Amount= Integer.parseInt(txt_amt.getText());
    String issue;
    try {
           Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            String sql = "select I.ISSUED_ID,B.BOOK_NAME,T.ARREARS,S.FIRST_NAME,I.ISSUE_DATE,I.RETURN_DATE from HR1.ISSUED_BOOKS I JOIN HR1.BOOKS B ON B.BOOK_ID=I.BOOK_ID JOIN HR1.STUDENT S ON S.STUDENT_ID=I.STUDENT_ID JOIN HR1.TRANSACTION T ON T.ISSUE_ID=I.ISSUED_ID where I.book_id = ? and I.student_id = ? and I.status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, bookId);
            pst.setInt(2, studentId);
            pst.setString(3, "OUT");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                lbl_issueId.setText(rs.getString("ISSUED_ID"));
                lbl_bookName.setText(rs.getString("book_name"));
                lbl_studentName.setText(rs.getString("first_name"));
                lbl_issueDate.setText(rs.getString("issue_date"));
                lbl_dueDate.setText(rs.getString("return_date"));
                  lbl_arrears.setText(rs.getString("ARREARS"));
               arr= rs.getInt("ARREARS");
            issue= rs.getString("ISSUED_ID");
                lbl_bookError.setText("");
               Amount=arr-Amount;
               updateArrears(con,issue,studentId,Amount);
            } 
        } catch (Exception e) {
            e.printStackTrace();
        }
       return isupt;}
     
public boolean canReturn() {
    boolean canReturn = true;

    // Retrieve relevant information (you may need to adapt this part based on your database schema)
    String bookId = "B" + txt_bookId.getText();
    int studentId = Integer.parseInt(txt_studentId.getText());

    try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "abc123")) {
        // If the return date is before the current date, join with the TRANSACTION table
        String sql = "SELECT I.RETURN_DATE, T.ARREARS FROM HR1.ISSUED_BOOKS I JOIN HR1.TRANSACTION T ON T.ISSUE_ID=I.ISSUED_ID WHERE I.BOOK_ID = ? AND I.STUDENT_ID = ? AND I.STATUS = 'OUT'";
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, bookId);
            pst.setInt(2, studentId);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    LocalDate returnDate = rs.getDate("RETURN_DATE").toLocalDate();
                    Double arrears = rs.getDouble("ARREARS");

                    // Check if the return is allowed
                    if (returnDate.isBefore(LocalDate.now()) && arrears > 0) {
                        canReturn = false;
                    }
                } else {
                    // No record found (book not issued or already returned)
                    canReturn = false;
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return canReturn;
}

public boolean canReturnBookW() {
    boolean canReturn = true;

    // Retrieve relevant information (you may need to adapt this part based on your database schema)
    String bookId = "B" + txt_bookId.getText();
    int studentId = Integer.parseInt(txt_studentId.getText());

    try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "abc123")) {
        // If the return date is not before the current date, use a different query without joining TRANSACTION
        String sqlWithoutTransaction = "SELECT RETURN_DATE FROM HR1.ISSUED_BOOKS WHERE BOOK_ID = ? AND STUDENT_ID = ? AND STATUS = 'OUT'";
        try (PreparedStatement pstWithoutTransaction = con.prepareStatement(sqlWithoutTransaction)) {
            pstWithoutTransaction.setString(1, bookId);
            pstWithoutTransaction.setInt(2, studentId);

            try (ResultSet rsWithoutTransaction = pstWithoutTransaction.executeQuery()) {
                if (rsWithoutTransaction.next()) {
                    LocalDate returnDate = rsWithoutTransaction.getDate("RETURN_DATE").toLocalDate();

                    // Check if the return is allowed without TRANSACTION
                    if (returnDate.isBefore(LocalDate.now())) {
                        canReturn = false;
                    }
                } else {
                    // No record found (book not issued or already returned)
                    canReturn = false;
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return canReturn;
}
 
    //updating book count
    public void updateBookCount() {
        String bookId = "B"+txt_bookId.getText();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            String sql = "update HR1.BOOKS set total_qty= total_qty + 1 where book_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, bookId);

            int rowCount = pst.executeUpdate();

            if (rowCount > 0) {
                JOptionPane.showMessageDialog(this, "book count updated");
                
               
            } else {
                JOptionPane.showMessageDialog(this, "can't update book count");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }}
 
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lbl_dueDate = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        lbl_bookName = new javax.swing.JLabel();
        lbl_studentName = new javax.swing.JLabel();
        lbl_issueId = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        lbl_issueDate = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        lbl_bookError = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        lbl_arrears = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_bookId = new app.bolivia.swing.JCTextField();
        txt_studentId = new app.bolivia.swing.JCTextField();
        jLabel14 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        rSLabelImage1 = new rojerusan.RSLabelImage();
        rSMaterialButtonRectangle1 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle2 = new rojerusan.RSMaterialButtonRectangle();
        jLabel26 = new javax.swing.JLabel();
        txt_amt = new app.bolivia.swing.JCTextField();
        UpdateBtn = new rojerusan.RSMaterialButtonRectangle();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-more-details-64.png"))); // NOI18N
        jLabel12.setText("  Book Details");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 300, 80));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 320, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 85, 320, 10));

        lbl_dueDate.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_dueDate.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_dueDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 360, 210, 40));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Book name : ");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 130, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Student Name : ");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 170, -1));

        lbl_bookName.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_bookName.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_bookName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 190, 40));

        lbl_studentName.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_studentName.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 190, 40));

        lbl_issueId.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_issueId.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_issueId, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 170, 40));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Due Date : ");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 130, -1));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Issue Date : ");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 130, -1));

        lbl_issueDate.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_issueDate.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_issueDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 210, 40));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Issue Id : ");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 120, -1));

        lbl_bookError.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jPanel3.add(lbl_bookError, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 270, 30));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Arrears : ");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 130, -1));

        lbl_arrears.setFont(new java.awt.Font("Yu Gothic UI", 0, 20)); // NOI18N
        lbl_arrears.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_arrears, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 410, 210, 40));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 360, 550));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 25)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-return-book-64.png"))); // NOI18N
        jLabel1.setText("   Return Book");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 0, 250, 80));

        jPanel7.setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 90, 280, 10));

        jPanel8.setBackground(new java.awt.Color(255, 51, 51));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 35)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("X");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1650, 0, 90, 40));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 102));
        jLabel9.setText("Book Id : ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 150, 100, 30));

        txt_bookId.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 153, 153)));
        txt_bookId.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_bookId.setPlaceholder("Enter Book Id ...");
        txt_bookId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_bookIdFocusLost(evt);
            }
        });
        getContentPane().add(txt_bookId, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 140, 260, 40));

        txt_studentId.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 153, 153)));
        txt_studentId.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_studentId.setPlaceholder("Enter Student Id ...");
        txt_studentId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_studentIdFocusLost(evt);
            }
        });
        txt_studentId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_studentIdActionPerformed(evt);
            }
        });
        getContentPane().add(txt_studentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 210, 260, 40));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 102, 102));
        jLabel14.setText("Student Id :");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 220, 110, 30));

        jPanel5.setBackground(new java.awt.Color(255, 0, 51));

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel11.setText("Back");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 50));

        rSLabelImage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/new bgs/OF71XX0.jpg"))); // NOI18N
        getContentPane().add(rSLabelImage1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 480, 520));

        rSMaterialButtonRectangle1.setText("FIND");
        rSMaterialButtonRectangle1.setContentAreaFilled(false);
        rSMaterialButtonRectangle1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonRectangle1MouseClicked(evt);
            }
        });
        getContentPane().add(rSMaterialButtonRectangle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 350, 170, 60));

        rSMaterialButtonRectangle2.setText("RETURN BOOK");
        rSMaterialButtonRectangle2.setContentAreaFilled(false);
        rSMaterialButtonRectangle2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonRectangle2MouseClicked(evt);
            }
        });
        getContentPane().add(rSMaterialButtonRectangle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 350, 160, 60));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 102, 102));
        jLabel26.setText("Amount:");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 290, 110, 30));

        txt_amt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 153, 153)));
        txt_amt.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_amt.setPlaceholder("Enter amount paid");
        txt_amt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_amtFocusLost(evt);
            }
        });
        txt_amt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_amtActionPerformed(evt);
            }
        });
        getContentPane().add(txt_amt, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 280, 260, 40));

        UpdateBtn.setText("UPDATE STATUS");
        UpdateBtn.setContentAreaFilled(false);
        UpdateBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateBtnMouseClicked(evt);
            }
        });
        UpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateBtnActionPerformed(evt);
            }
        });
        getContentPane().add(UpdateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 410, 170, 60));

        setSize(new java.awt.Dimension(1240, 513));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        HomePage home = new HomePage();
        home.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void txt_studentIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_studentIdFocusLost

    }//GEN-LAST:event_txt_studentIdFocusLost

    private void txt_studentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_studentIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_studentIdActionPerformed

    private void txt_bookIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_bookIdFocusLost

    }//GEN-LAST:event_txt_bookIdFocusLost

    private void rSMaterialButtonRectangle1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle1MouseClicked
         getIssueBookDetails();  
    }//GEN-LAST:event_rSMaterialButtonRectangle1MouseClicked

    private void rSMaterialButtonRectangle2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle2MouseClicked
        
            if(canReturn()==true){
               
                    
            JOptionPane.showMessageDialog(this, "Book Returned Successfully");
           updateBookStatusToIn();
            updateBookCount();
        }
            else if(canReturnBookW()==true){
                 JOptionPane.showMessageDialog(this, "Book Returned Successfully");
                 updateBookStatusToIn();
            updateBookCount();
            }
            
            else{
            JOptionPane.showMessageDialog(this, "Book Returned Failed Due to Amount Overhead");
         }
    }//GEN-LAST:event_rSMaterialButtonRectangle2MouseClicked

    private void txt_amtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_amtFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_amtFocusLost

    private void txt_amtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_amtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_amtActionPerformed

    private void UpdateBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateBtnMouseClicked
        // TODO add your handling code here:
        if(UpdateStatus()==true){

            JOptionPane.showMessageDialog(this, "Updation unsuccessful");
        }
        else{
            JOptionPane.showMessageDialog(this, "updated");}
    }//GEN-LAST:event_UpdateBtnMouseClicked

    private void UpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReturnBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSMaterialButtonRectangle UpdateBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JLabel lbl_arrears;
    private javax.swing.JLabel lbl_bookError;
    private javax.swing.JLabel lbl_bookName;
    private javax.swing.JLabel lbl_dueDate;
    private javax.swing.JLabel lbl_issueDate;
    private javax.swing.JLabel lbl_issueId;
    private javax.swing.JLabel lbl_studentName;
    private rojerusan.RSLabelImage rSLabelImage1;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle1;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle2;
    private app.bolivia.swing.JCTextField txt_amt;
    private app.bolivia.swing.JCTextField txt_bookId;
    private app.bolivia.swing.JCTextField txt_studentId;
    // End of variables declaration//GEN-END:variables
}
