/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;

import jaco.mp3.player.MP3Player;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jframe.ManageBooks.message;

/**
 *
 * @author sunil
 */
public class ManageStudents extends javax.swing.JFrame {
static String message;
      public static String getMessage(){
    return message;
} /**
     * Creates new form ManageBooks
     */
    String First_Name,course,Last_name,email;
    int studentId;
    DefaultTableModel model;
    public ManageStudents() {
        initComponents();
        setStudentDetailsToTable();
        errorlabel.setVisible(false);
        errorlabe.setVisible(false); 
         
    }
    public void setStudentDetailsToTable(){
        try {
             Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("Select S.STUDENT_ID,S.FIRST_NAME,S.LAST_NAME,S.EMAIL,D.DEPARTMENT_NAME,U.PASSWORD from HR1.STUDENT S JOIN HR1.USER_ROLES U ON S.STUDENT_ID=U.ID JOIN HR1.DEPARTMENT D ON S.DEPARTMENT_ID=D.DEPARTMENT_ID");
            while(rs.next()){
                int StudentId = rs.getInt("Student_id");
                String First_Name = rs.getString("First_Name");
                String Last_Name = rs.getString("Last_Name"); 
                String email = rs.getString("email");
                password=rs.getString("PASSWORD");
                String course = rs.getString("Department_NAME");
                Object[] obj = {StudentId,password,First_Name,Last_Name,email,course};
                model =(DefaultTableModel) tbl_studentDetails.getModel();
                model.addRow(obj);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public boolean addStudent(){
        boolean isAdded = false;
        studentId = Integer.parseInt(txt_studentId.getText());
        First_Name = txt_studentName.getText();
        course = combo_CourseName.getSelectedItem().toString();
       Last_name = txt_pass.getText();
        email = txt_email.getText();
        String pass=txt_pass1.getText();
        try {
           Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            String sql = "insert into HR1.STUDENT values(?,?,?,?,?)";
            
            String sql2="Select * from hr1.Department where department_name=?";
          PreparedStatement pst2 = con.prepareStatement(sql2);
           pst2.setString(1, course);
            ResultSet s = pst2.executeQuery();
            if(s.next()){
            course=s.getString("Department_id");
            
                
         
          
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
            pst.setString(2, First_Name);
            pst.setString(3, Last_name);
            pst.setString(4, email); 
            pst.setString(5, course);
             String sql1 = "insert into HR1.USER_ROLES (id,password,role_id)values(?,?,?)";
              PreparedStatement pst1 = con.prepareStatement(sql1);
             pst1.setInt(3,0);
             pst1.setInt(1, studentId);
             pst1.setString(2, pass);
             pst1.executeQuery();
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isAdded = true;
                JavaMailUtil.newstudentsmail(email,First_Name,studentId,pass);

            }}else{
                isAdded = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isAdded;
            } 
    public boolean updateStudent(){

      boolean isUpdated = false;
       studentId = Integer.parseInt(txt_studentId.getText());
        First_Name = txt_studentName.getText();
        course = combo_CourseName.getSelectedItem().toString();
       Last_name = txt_pass.getText();
        email = txt_email.getText();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            String sql = "update HR1.STUDENT set FIRST_NAME = ?,LAST_NAME=?, EMAIL=? ,DEPARTMENT = ? where STUDENT_ID = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(5,studentId);
            pst.setString(1, First_Name);
            pst.setString(2, Last_name);
            pst.setString(3, email);
              pst.setString(4, course);
                
            
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isUpdated = true;
            }else{
                isUpdated = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isUpdated;
    }

    
    
    //method to delete book detail
    public boolean deleteStudent(){
        boolean isDeleted = false;
        studentId = Integer.parseInt(txt_studentId.getText());
       
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            String sql = "DELETE FROM HR1.STUDENT  where STUDENT_ID = ?";
            String sql2="DELETE FROM HR1.USER_ROLES  where ID = ?";
    
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
              PreparedStatement pst1 = con.prepareStatement(sql2);
            pst1.setInt(1, studentId);
            pst1.executeUpdate();
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isDeleted = true;
            }else{
                isDeleted = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }
    public void clearTable(){
        DefaultTableModel model = (DefaultTableModel) tbl_studentDetails.getModel();
        model.setRowCount(0);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_studentId = new app.bolivia.swing.JCTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_studentName = new app.bolivia.swing.JCTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        combo_CourseName = new javax.swing.JComboBox<>();
        errorlabel = new java.awt.Label();
        errorlabe = new java.awt.Label();
        passlab = new javax.swing.JLabel();
        txt_pass = new app.bolivia.swing.JCTextField();
        txt_email = new app.bolivia.swing.JCTextField();
        passlab1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        passlab2 = new javax.swing.JLabel();
        txt_pass1 = new app.bolivia.swing.JCTextField();
        errorlabel2 = new java.awt.Label();
        jLabel14 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_studentDetails = new rojeru_san.complementos.RSTableMetro();
        rSMaterialButtonRectangle1 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle2 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle3 = new rojerusan.RSMaterialButtonRectangle();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_studentId.setBackground(new java.awt.Color(0, 102, 102));
        txt_studentId.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_studentId.setForeground(new java.awt.Color(255, 255, 255));
        txt_studentId.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_studentId.setPhColor(new java.awt.Color(255, 255, 255));
        txt_studentId.setPlaceholder("Enter Student Id ...");
        txt_studentId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_studentIdFocusLost(evt);
            }
        });
        txt_studentId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_studentIdKeyPressed(evt);
            }
        });
        jPanel1.add(txt_studentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 260, 40));

        jLabel9.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Enter Student Id ");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 310, 30));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 60, 50));

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Enter First Name : ");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 210, 30));

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 60, 50));

        txt_studentName.setBackground(new java.awt.Color(0, 102, 102));
        txt_studentName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_studentName.setForeground(new java.awt.Color(255, 255, 255));
        txt_studentName.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_studentName.setPhColor(new java.awt.Color(255, 255, 255));
        txt_studentName.setPlaceholder("Enter Student Name :  ...");
        txt_studentName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_studentNameFocusLost(evt);
            }
        });
        txt_studentName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_studentNameKeyPressed(evt);
            }
        });
        jPanel1.add(txt_studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 260, 40));

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Select Course");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 540, 310, 30));

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 580, 60, 60));

        jPanel4.setBackground(new java.awt.Color(255, 51, 51));
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel2.setText("Back");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(0, 2, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 50));

        combo_CourseName.setBackground(new java.awt.Color(153, 153, 153));
        combo_CourseName.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        combo_CourseName.setForeground(new java.awt.Color(255, 255, 255));
        combo_CourseName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BSC", "MSC", "PHD" }));
        combo_CourseName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_CourseNameActionPerformed(evt);
            }
        });
        jPanel1.add(combo_CourseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 590, 260, 40));

        errorlabel.setBackground(new java.awt.Color(255, 0, 51));
        errorlabel.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        errorlabel.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(errorlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 210, 30));

        errorlabe.setBackground(new java.awt.Color(255, 0, 51));
        errorlabe.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        errorlabe.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(errorlabe, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 450, 210, 30));

        passlab.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        passlab.setForeground(new java.awt.Color(255, 255, 255));
        passlab.setText("Enter Last Name : ");
        jPanel1.add(passlab, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 210, 30));

        txt_pass.setBackground(new java.awt.Color(0, 102, 102));
        txt_pass.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_pass.setForeground(new java.awt.Color(255, 255, 255));
        txt_pass.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_pass.setPhColor(new java.awt.Color(255, 255, 255));
        txt_pass.setPlaceholder("Enter Last Name ..");
        txt_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passFocusLost(evt);
            }
        });
        txt_pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_passActionPerformed(evt);
            }
        });
        txt_pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_passKeyPressed(evt);
            }
        });
        jPanel1.add(txt_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 260, 40));

        txt_email.setBackground(new java.awt.Color(0, 102, 102));
        txt_email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_email.setForeground(new java.awt.Color(255, 255, 255));
        txt_email.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_email.setPhColor(new java.awt.Color(255, 255, 255));
        txt_email.setPlaceholder("Enter email :");
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });
        txt_email.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_emailKeyPressed(evt);
            }
        });
        jPanel1.add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 500, 260, 40));

        passlab1.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        passlab1.setForeground(new java.awt.Color(255, 255, 255));
        passlab1.setText("Enter Email : ");
        jPanel1.add(passlab1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 460, 210, 30));

        jLabel13.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/ns.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 40, 50));

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 60, 50));

        passlab2.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        passlab2.setForeground(new java.awt.Color(255, 255, 255));
        passlab2.setText("Enter Password: ");
        jPanel1.add(passlab2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 370, 210, 30));

        txt_pass1.setBackground(new java.awt.Color(0, 102, 102));
        txt_pass1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_pass1.setForeground(new java.awt.Color(255, 255, 255));
        txt_pass1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_pass1.setPhColor(new java.awt.Color(255, 255, 255));
        txt_pass1.setPlaceholder("Enter Last Name ..");
        txt_pass1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_pass1FocusLost(evt);
            }
        });
        txt_pass1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_pass1ActionPerformed(evt);
            }
        });
        txt_pass1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_pass1KeyPressed(evt);
            }
        });
        jPanel1.add(txt_pass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 260, 40));

        errorlabel2.setBackground(new java.awt.Color(255, 0, 51));
        errorlabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        errorlabel2.setForeground(new java.awt.Color(255, 255, 255));
        errorlabel2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                errorlabel2KeyPressed(evt);
            }
        });
        jPanel1.add(errorlabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 210, 30));

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/ns.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, 40, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 830));

        jPanel5.setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 130, -1, 5));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 102));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-students-64.png"))); // NOI18N
        jLabel3.setText("  Manage Students");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 20, 390, 100));

        tbl_studentDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Id", "Password", "First Name", "Last Name", "Email", "Department"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_studentDetails.setColorBackgoundHead(new java.awt.Color(0, 102, 102));
        tbl_studentDetails.setColorBordeFilas(new java.awt.Color(0, 102, 102));
        tbl_studentDetails.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        tbl_studentDetails.setColorFilasForeground1(new java.awt.Color(0, 0, 0));
        tbl_studentDetails.setColorFilasForeground2(new java.awt.Color(0, 0, 0));
        tbl_studentDetails.setColorSelBackgound(new java.awt.Color(204, 255, 204));
        tbl_studentDetails.setColorSelForeground(new java.awt.Color(0, 0, 0));
        tbl_studentDetails.setFont(new java.awt.Font("Yu Gothic UI Light", 0, 25)); // NOI18N
        tbl_studentDetails.setFuenteFilas(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        tbl_studentDetails.setFuenteFilasSelect(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        tbl_studentDetails.setFuenteHead(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        tbl_studentDetails.setRowHeight(40);
        tbl_studentDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_studentDetailsMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_studentDetails);
        if (tbl_studentDetails.getColumnModel().getColumnCount() > 0) {
            tbl_studentDetails.getColumnModel().getColumn(0).setResizable(false);
            tbl_studentDetails.getColumnModel().getColumn(1).setResizable(false);
            tbl_studentDetails.getColumnModel().getColumn(2).setResizable(false);
            tbl_studentDetails.getColumnModel().getColumn(4).setResizable(false);
            tbl_studentDetails.getColumnModel().getColumn(5).setResizable(false);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 720, 290));

        rSMaterialButtonRectangle1.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle1.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle1.setText("ADD");
        rSMaterialButtonRectangle1.setContentAreaFilled(false);
        rSMaterialButtonRectangle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle1ActionPerformed(evt);
            }
        });
        getContentPane().add(rSMaterialButtonRectangle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 560, 180, -1));

        rSMaterialButtonRectangle2.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle2.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle2.setText("update");
        rSMaterialButtonRectangle2.setContentAreaFilled(false);
        rSMaterialButtonRectangle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle2ActionPerformed(evt);
            }
        });
        getContentPane().add(rSMaterialButtonRectangle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 560, 180, -1));

        rSMaterialButtonRectangle3.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle3.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle3.setText("delete");
        rSMaterialButtonRectangle3.setContentAreaFilled(false);
        rSMaterialButtonRectangle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle3ActionPerformed(evt);
            }
        });
        getContentPane().add(rSMaterialButtonRectangle3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 560, 180, -1));

        setSize(new java.awt.Dimension(1221, 675));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_studentIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_studentIdFocusLost

    }//GEN-LAST:event_txt_studentIdFocusLost

    private void txt_studentNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_studentNameFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_studentNameFocusLost

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
     HomePage home = new HomePage();
     home.setVisible(true);
     dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    private void tbl_studentDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_studentDetailsMouseClicked
        int rowNo = tbl_studentDetails.getSelectedRow();
        TableModel model = tbl_studentDetails.getModel();
        txt_studentId.setText(model.getValueAt(rowNo, 0).toString());
        txt_pass.setText(model.getValueAt(rowNo,3).toString());
         txt_pass1.setText(model.getValueAt(rowNo,1).toString());
        txt_studentName.setText(model.getValueAt(rowNo, 2).toString());
        txt_email.setText(model.getValueAt(rowNo, 4).toString());
        combo_CourseName.setSelectedItem(model.getValueAt(rowNo, 5).toString());
       
      txt_pass1.setEditable(false);

    }//GEN-LAST:event_tbl_studentDetailsMouseClicked

    private void combo_CourseNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_CourseNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo_CourseNameActionPerformed
       public static final String del_song ="D:\\Library_Management_System\\Library_Management_System\\delete.mp3";
       MP3Player del_sound = new MP3Player(new File(del_song));
       public static final String song ="D:\\Library_Management_System\\Library_Management_System\\add.mp3";
       MP3Player mp3player = new MP3Player(new File(song));
    
    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked
        HomePage homePage = new HomePage();
        homePage.setVisible(true);
        dispose();
    }//GEN-LAST:event_jPanel4MouseClicked

    private void txt_studentNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_studentNameKeyPressed
          char c = evt.getKeyChar();
            if(Character.isDigit(c)){
            errorlabel2.setText("Warning!Enter alphabets only");
            errorlabel2.setVisible(true);
        }  
            else{
                         errorlabel2.setVisible(false);
   
            }
    }//GEN-LAST:event_txt_studentNameKeyPressed

    private void txt_studentIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_studentIdKeyPressed
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            errorlabel.setText("Warning!Enter digits only");
            errorlabel.setVisible(true);
        }    
        else{
            errorlabel.setVisible(false);

        }
    }//GEN-LAST:event_txt_studentIdKeyPressed

    private void txt_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passFocusLost

    private void txt_passKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passKeyPressed

    private void txt_passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passActionPerformed

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailFocusLost

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void txt_emailKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_emailKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailKeyPressed

    private void rSMaterialButtonRectangle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle1ActionPerformed
       
         String inputString = txt_pass1.getText();
        if(txt_studentId.getText().isEmpty()||txt_pass.getText().isEmpty()||txt_email.getText().isEmpty()|| txt_pass.getText().isEmpty()||txt_studentName.getText().isEmpty()){
         JOptionPane.showMessageDialog(this, "Fill all the fields");
        }
      
 
        else if(inputString.length() != 9 ){
            JOptionPane.showMessageDialog(this, "9 length only"); 
        }
        else if (Pattern.matches(".*\\d+.*", txt_studentName.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter alphabets only");
    message = "Warning! Enter alphabets only";
} else if (Pattern.matches(".*[a-zA-Z]+.*", txt_studentId.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter numbers only");
    message = "Warning! Enter numbers only";
}
        
        else{
        if (addStudent()== true) {
            mp3player.play();
            JOptionPane.showMessageDialog(this, "Student Added");
            clearTable();
            setStudentDetailsToTable();
            txt_pass1.setEditable(true);
        }else{
            JOptionPane.showMessageDialog(this, "Student Already exsist with same Email or Id");
        }}
    }//GEN-LAST:event_rSMaterialButtonRectangle1ActionPerformed

    private void rSMaterialButtonRectangle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle3ActionPerformed
       if (deleteStudent()== true) {
           int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
           if(response == JOptionPane.YES_OPTION){
               del_sound.play();
           JOptionPane.showMessageDialog(this, "student Deleted");
            clearTable();
            setStudentDetailsToTable();
            txt_pass1.setEditable(true);
           }
                   }else{
         JOptionPane.showMessageDialog(this, "student Deletion Failed");
        } 
    }//GEN-LAST:event_rSMaterialButtonRectangle3ActionPerformed

    private void rSMaterialButtonRectangle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle2ActionPerformed
         if (updateStudent()== true) {
            JOptionPane.showMessageDialog(this, "Student Updated");
            clearTable();
            setStudentDetailsToTable();
            txt_pass1.setEditable(true);
        }else{
             
            JOptionPane.showMessageDialog(this, "student Updation Failed");
        }
    }//GEN-LAST:event_rSMaterialButtonRectangle2ActionPerformed

    private void txt_pass1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_pass1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_pass1FocusLost

    private void txt_pass1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_pass1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_pass1ActionPerformed

    private void txt_pass1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_pass1KeyPressed
        // TODO add your handling code here:
     String inputString = txt_pass1.getText();
if (inputString.length() != 9 ) {
    errorlabe.setText("9 length only");
            errorlabe.setVisible(true);
} 

else {
    errorlabe.setVisible(false);
}

        
        
    }//GEN-LAST:event_txt_pass1KeyPressed

    private void errorlabel2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_errorlabel2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_errorlabel2KeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageStudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageStudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageStudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageStudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageStudents().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> combo_CourseName;
    private java.awt.Label errorlabe;
    private java.awt.Label errorlabel;
    private java.awt.Label errorlabel2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel passlab;
    private javax.swing.JLabel passlab1;
    private javax.swing.JLabel passlab2;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle1;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle2;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle3;
    private rojeru_san.complementos.RSTableMetro tbl_studentDetails;
    private app.bolivia.swing.JCTextField txt_email;
    private app.bolivia.swing.JCTextField txt_pass;
    private app.bolivia.swing.JCTextField txt_pass1;
    private app.bolivia.swing.JCTextField txt_studentId;
    private app.bolivia.swing.JCTextField txt_studentName;
    // End of variables declaration//GEN-END:variables
}
