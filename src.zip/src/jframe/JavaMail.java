/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jframe;

/**
 *
 * @author BSP
 */
public class JavaMail {
    public static void main(String[] args ) throws Exception{
        JavaMailUtil.sendmail("beenishalik700@gmail.com");
    }
}
