/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;

import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sunil
 */
public class details extends javax.swing.JFrame {

    /**
     * Creates new form ViewAllRecord
     */
static int id1;
    public details(int  id) {
        initComponents();
        searchall();
         id1=id;
     
        //search5();
    }
    
  
   public void searchall() {
    try {

        Class.forName("oracle.jdbc.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);
        String searchSql = "SELECT * FROM HR1.bookS";
        try (PreparedStatement pst = con.prepareStatement(searchSql);
             ResultSet rs = pst.executeQuery()) {
            int count = 1; 
            while (rs.next() && count <= 6) { 
                byte[] imgData = rs.getBytes("image");
                ImageIcon imageIcon = new ImageIcon(imgData);
                Image im = imageIcon.getImage();
                Image myImg = im.getScaledInstance(240, 240, Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);

          
                switch (count) {
                    case 1:
                        imagee1.setImagen(newImage);
                        break;
                    case 2:
                        imagee2.setImagen(newImage);
                        break;
                    case 3:
                        imagee3.setIcon(newImage);
                        break;
                    case 4:
                        imagee4.setImagen(newImage);
                        break;
                    case 5:
                        imagee5.setImagen(newImage);
                        break;
                    case 6:
                        imagee6.setImagen(newImage);
                        break;
                          case 7:
                        imagee7.setImagen(newImage);
                        break;
                    case 8:
                        imagee8.setImagen(newImage);
                        break;
                    case 9:
                        imagee9.setImagen(newImage);
                        break;
                    case 10:
                        imagee10.setImagen(newImage);
                        break;
                    case 11:
                        imagee12.setImagen(newImage);
                        break;
                    case 12:
                        imagee13.setImagen(newImage);
                        break;
                        
                }

                count++;
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        imagee4 = new rojerusan.RSPanelImage();
        imagee5 = new rojerusan.RSPanelImage();
        imagee6 = new rojerusan.RSPanelImage();
        imagee3 = new rojerusan.RSLabelImage();
        imagee2 = new rojerusan.RSPanelImage();
        imagee10 = new rojerusan.RSPanelImage();
        imagee12 = new rojerusan.RSPanelImage();
        imagee13 = new rojerusan.RSPanelImage();
        jLabel2 = new javax.swing.JLabel();
        imagee1 = new rojerusan.RSPanelImage();
        imagee7 = new rojerusan.RSPanelImage();
        imagee8 = new rojerusan.RSPanelImage();
        imagee9 = new rojerusan.RSPanelImage();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 310, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 120, 310, 10));

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Literature_100px_1.png"))); // NOI18N
        jLabel12.setText(" All Books");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 10, 320, 110));

        jPanel7.setBackground(new java.awt.Color(255, 51, 51));

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel14.setText("Back");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel14))
        );

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 160));

        javax.swing.GroupLayout imagee4Layout = new javax.swing.GroupLayout(imagee4);
        imagee4.setLayout(imagee4Layout);
        imagee4Layout.setHorizontalGroup(
            imagee4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        imagee4Layout.setVerticalGroup(
            imagee4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, 100, 160));

        javax.swing.GroupLayout imagee5Layout = new javax.swing.GroupLayout(imagee5);
        imagee5.setLayout(imagee5Layout);
        imagee5Layout.setHorizontalGroup(
            imagee5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        imagee5Layout.setVerticalGroup(
            imagee5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 190, 100, 160));

        javax.swing.GroupLayout imagee6Layout = new javax.swing.GroupLayout(imagee6);
        imagee6.setLayout(imagee6Layout);
        imagee6Layout.setHorizontalGroup(
            imagee6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee6Layout.setVerticalGroup(
            imagee6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee6, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 190, 110, 160));
        getContentPane().add(imagee3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 110, 160));

        javax.swing.GroupLayout imagee2Layout = new javax.swing.GroupLayout(imagee2);
        imagee2.setLayout(imagee2Layout);
        imagee2Layout.setHorizontalGroup(
            imagee2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee2Layout.setVerticalGroup(
            imagee2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 110, 160));

        javax.swing.GroupLayout imagee10Layout = new javax.swing.GroupLayout(imagee10);
        imagee10.setLayout(imagee10Layout);
        imagee10Layout.setHorizontalGroup(
            imagee10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        imagee10Layout.setVerticalGroup(
            imagee10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 440, -1, 160));

        javax.swing.GroupLayout imagee12Layout = new javax.swing.GroupLayout(imagee12);
        imagee12.setLayout(imagee12Layout);
        imagee12Layout.setHorizontalGroup(
            imagee12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        imagee12Layout.setVerticalGroup(
            imagee12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee12, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 440, -1, 160));

        javax.swing.GroupLayout imagee13Layout = new javax.swing.GroupLayout(imagee13);
        imagee13.setLayout(imagee13Layout);
        imagee13Layout.setHorizontalGroup(
            imagee13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        imagee13Layout.setVerticalGroup(
            imagee13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee13, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 440, -1, 160));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/images (1).jpeg"))); // NOI18N
        jLabel2.setToolTipText("");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 160, 540, 530));

        javax.swing.GroupLayout imagee1Layout = new javax.swing.GroupLayout(imagee1);
        imagee1.setLayout(imagee1Layout);
        imagee1Layout.setHorizontalGroup(
            imagee1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee1Layout.setVerticalGroup(
            imagee1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 110, 160));

        javax.swing.GroupLayout imagee7Layout = new javax.swing.GroupLayout(imagee7);
        imagee7.setLayout(imagee7Layout);
        imagee7Layout.setHorizontalGroup(
            imagee7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee7Layout.setVerticalGroup(
            imagee7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 440, -1, 160));

        javax.swing.GroupLayout imagee8Layout = new javax.swing.GroupLayout(imagee8);
        imagee8.setLayout(imagee8Layout);
        imagee8Layout.setHorizontalGroup(
            imagee8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee8Layout.setVerticalGroup(
            imagee8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, -1, 160));

        javax.swing.GroupLayout imagee9Layout = new javax.swing.GroupLayout(imagee9);
        imagee9.setLayout(imagee9Layout);
        imagee9Layout.setHorizontalGroup(
            imagee9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        imagee9Layout.setVerticalGroup(
            imagee9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );

        getContentPane().add(imagee9, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 440, -1, 160));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/images (1).jpeg"))); // NOI18N
        jLabel3.setToolTipText("");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 550, 530));

        setSize(new java.awt.Dimension(1101, 689));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        student_dashboard StudentDashboard = new student_dashboard(id1);
        StudentDashboard.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel14MouseClicked

    private void imagee4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee4MouseClicked
      
    }//GEN-LAST:event_imagee4MouseClicked

    private void imagee1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee1MouseClicked
       
    }//GEN-LAST:event_imagee1MouseClicked

    private void imagee2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee2MouseClicked
      
    }//GEN-LAST:event_imagee2MouseClicked

    private void imagee3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee3MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_imagee3MouseClicked

    private void imagee5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee5MouseClicked
      
    }//GEN-LAST:event_imagee5MouseClicked

    private void imagee6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagee6MouseClicked
       
    }//GEN-LAST:event_imagee6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new details(id1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSPanelImage imagee1;
    private rojerusan.RSPanelImage imagee10;
    private rojerusan.RSPanelImage imagee12;
    private rojerusan.RSPanelImage imagee13;
    private rojerusan.RSPanelImage imagee2;
    private rojerusan.RSLabelImage imagee3;
    private rojerusan.RSPanelImage imagee4;
    private rojerusan.RSPanelImage imagee5;
    private rojerusan.RSPanelImage imagee6;
    private rojerusan.RSPanelImage imagee7;
    private rojerusan.RSPanelImage imagee8;
    private rojerusan.RSPanelImage imagee9;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    // End of variables declaration//GEN-END:variables
}
