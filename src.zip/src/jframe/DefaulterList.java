/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Random;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sunil
 */
public class DefaulterList extends javax.swing.JFrame {

    /**
     * Creates new form IssuebookDetails
     */
     DefaultTableModel model;
    public DefaulterList() {
        initComponents();
        clearTable();
       calculateArrears();
    
        setIssueBookDetailsToTable();
    
    }
    
     public void clearTable(){
        DefaultTableModel model = (DefaultTableModel) tbl_issueBookDetails.getModel();
        model.setRowCount(0);
    }
    Boolean calculateArrears() {
    boolean isCALC = false;
    
   
    try {
        Class.forName("oracle.jdbc.OracleDriver");

        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);

        String sql = "SELECT STUDENT_ID,ISSUED_ID, RETURN_DATE, ISSUE_DATE FROM HR1.ISSUED_BOOKS where STATUS=?";
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, "OUT");
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    String issuedId = rs.getString("ISSUED_ID");
                    LocalDate returnDate = rs.getDate("RETURN_DATE").toLocalDate();
                    LocalDate currentDate = LocalDate.now();
int studentId=rs.getInt("STUDENT_ID");
                    if (returnDate.isBefore(currentDate)) {
                        // Calculate arrears
                        long daysOverdue = ChronoUnit.DAYS.between(returnDate, currentDate);
                        double arrears = daysOverdue * 20;

                       
                        insertTransaction(con, issuedId,studentId ,arrears);
                       isCALC = true;
                    }
                }
            }
        }
       
    } catch (Exception e) {
        e.printStackTrace();
    }
      return isCALC ;}
  void insertTransaction(Connection con, String issuedId, int studentId, double arrears) {
    try {
        int transactionId = CheckIf(con, issuedId, studentId);

        if (transactionId == -1) {
            // Generate a unique transaction ID using a sequence or another method
            // For now, using a simple increment
           Random r = new Random();
        int num = r.nextInt(1000) + 1;
        int Id = studentId + num;


            String insertSql = "INSERT INTO HR1.TRANSACTION VALUES ( ?, ?, ?, ? )";
            try (PreparedStatement insertPst = con.prepareStatement(insertSql)) {
                insertPst.setInt(1, Id);
                insertPst.setString(2, issuedId);
                insertPst.setInt(3, studentId);
                insertPst.setDouble(4, arrears);

                insertPst.executeUpdate();
            }
        } else {
            String updateSql = "UPDATE HR1.TRANSACTION SET ARREARS=? WHERE ISSUE_ID=? AND TRANSACTION_ID=?";
            try (PreparedStatement updatePst = con.prepareStatement(updateSql)) {
                updatePst.setDouble(1, arrears);
                updatePst.setString(2, issuedId);
                updatePst.setInt(3, transactionId);

                updatePst.executeUpdate();
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    int CheckIf(Connection con, String issuedId, int studentId) {
    int transaction_id = -1;
    String selectSql = "SELECT TRANSACTION_ID FROM HR1.TRANSACTION WHERE ISSUE_ID = ?";
    
    try (PreparedStatement pst = con.prepareStatement(selectSql)) {
        pst.setString(1, issuedId);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            transaction_id = rs.getInt("TRANSACTION_ID");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    
    return transaction_id;
}
    
    
    public void setIssueBookDetailsToTable() {
        long l = System.currentTimeMillis();
        Date todaysDate = new Date(l);
        try {
            Class.forName("oracle.jdbc.OracleDriver");

        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);
            
            PreparedStatement pst = con.prepareStatement("Select B.BOOK_ID,C.STATUS,S.FIRST_NAME,S.LAST_NAME,T.ARREARS,C.STUDENT_ID,B.BOOK_NAME ,C.ISSUE_DATE,C.RETURN_DATE from HR1.BOOKS B  JOIN HR1.ISSUED_BOOKS C ON C.BOOK_ID=B.BOOK_ID JOIN HR1.STUDENT S ON S.STUDENT_ID=C.STUDENT_ID JOIN HR1.TRANSACTION T ON T.ISSUE_ID=C.ISSUED_ID WHERE C.RETURN_DATE<? AND C.STATUS=? AND T.ARREARS>0");

            pst.setDate(1, todaysDate);
            pst.setString(2, "OUT");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                String id = rs.getString("student_id");
                String bkid = rs.getString("book_id");
                int email = rs.getInt("ARREARS");
                String bookName = rs.getString("book_name");
                String StudentName = rs.getString("FIRST_NAME");
                String issueDate = rs.getString("issue_date");
                String dueDate = rs.getString("return_date");
                String status = rs.getString("status");
               

                Object[] obj = {id,email,bkid, bookName, StudentName, issueDate, dueDate, status};
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_issueBookDetails = new rojeru_san.complementos.RSTableMetro();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 25)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Edit_Property_50px.png"))); // NOI18N
        jLabel1.setText("    Defaulter List");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 50, 230, 50));

        jPanel7.setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 460, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, -1, 10));

        jPanel6.setBackground(new java.awt.Color(255, 51, 51));

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel20.setText("   Back");
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(jLabel20))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 140, -1));

        tbl_issueBookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Arrears", "Book ID", "Book Name", "Student Name", "Issue Date", "Due Date", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_issueBookDetails.setColorBackgoundHead(new java.awt.Color(0, 102, 102));
        tbl_issueBookDetails.setRowHeight(40);
        jScrollPane1.setViewportView(tbl_issueBookDetails);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 1120, 170));

        setSize(new java.awt.Dimension(1259, 616));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        HomePage homePage = new HomePage();
        homePage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel20MouseClicked

    private void tbl_issueBookDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_issueBookDetailsMouseClicked

    }//GEN-LAST:event_tbl_issueBookDetailsMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DefaulterList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DefaulterList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DefaulterList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DefaulterList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DefaulterList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private rojeru_san.complementos.RSTableMetro tbl_issueBookDetails;
    // End of variables declaration//GEN-END:variables
}
