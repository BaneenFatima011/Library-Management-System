/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;

import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sunil
 */
public class searchbookdetails extends javax.swing.JFrame {
static int id1;
DefaultListModel defaultListModel = new DefaultListModel();
    /**
     * Creates new form ViewAllRecord
     */
 public searchbookdetails(int id){
      id1=id;
     
       initComponents();
//               mylist.setVisible(false);

       
   } 
 private ArrayList getStars( ){
     ArrayList stars= new ArrayList();
     stars.add("great expectations");
     stars.add("All the Kings man");
     stars.add("The rainbow");
     stars.add("Invisible man");
     stars.add("Dracula");
     stars.add("Nice citizen");
     stars.add("heart of darkness");
     stars.add("Jannat ke patte");
     return stars;
 }
 private void binddata(String name ){
     getStars().stream().forEach((star)->{
      defaultListModel.addElement(star);   
     });
//     mylist.setModel(defaultListModel);
//     mylist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
     
 }
 private void searchfilter(String searchterm){
     DefaultListModel filteredItems = new DefaultListModel();
    ArrayList stars=getStars();
     
     stars.stream().forEach((star) -> {
         String starname =star.toString().toLowerCase();
         if(starname.contains(searchterm.toLowerCase()))
         {
          filteredItems.addElement(star);
         }
     });
     defaultListModel=filteredItems;
    // mylist.setModel(defaultListModel);
     }
    public searchbookdetails(String name,int id) {
        initComponents();
        
        String namee=name;
            try {
             Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            PreparedStatement pst = con.prepareStatement("select B.BOOK_ID,B.IMAGE,B.BOOK_NAME,A.FIRST_NAME,G.GENRE_NAME,B.TOTAL_QTY from HR1.BOOKS B JOIN HR1.AUTHORS A ON A.AUTHOR_ID=B.AUTHOR_ID JOIN HR1.GENRE G ON G.GENRE_ID=B.GENRE_ID WHERE B.BOOK_ID=?");
            pst.setString(1,namee );
            ResultSet rs = pst.executeQuery();

            if(rs.next()){             
                String author = rs.getString("First_name");
                String genre = rs.getString("genre_name");
                lbl_BookName.setText(namee);
                lbl_authorname.setText(author);
                lbl_genreshow.setText(genre);
                
                int status = Integer.parseInt(rs.getString("total_qty"));
                if(status>0){
                     lbl_status.setText("Available");
                }
                else{
                lbl_status.setText("Not Available");}
                byte [] img = rs.getBytes("image");
               ImageIcon image = new ImageIcon(img);
                Image im = image.getImage();
                Image myImg = im.getScaledInstance( 200,  400, Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                jLabel_Image_1.setImagen(newImage);
            }
            else{
                JOptionPane.showMessageDialog(null, "no data");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
            
    }
    public void search() {
            try {
             Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);;
            Statement st = con.createStatement();
            
            String searchbybookval = "%" + searchbybook.getText()  + "%";
            
            PreparedStatement pst = con.prepareStatement("select B.BOOK_ID,B.IMAGE,B.BOOK_NAME,A.FIRST_NAME,G.GENRE_NAME,B.TOTAL_QTY from HR1.BOOKS B JOIN HR1.AUTHORS A ON A.AUTHOR_ID=B.AUTHOR_ID JOIN HR1.GENRE G ON G.GENRE_ID=B.GENRE_ID where  b.book_name like ? or g.genre_name like ?");
            pst.setString(1,searchbybookval );
            pst.setString(2,searchbybookval );
            
            ResultSet rs = pst.executeQuery();
           
            if(rs.next()){
               String namee = rs.getString("BOOK_NAME");
                String author = rs.getString("FIRST_NAME");
                String genre = rs.getString("GENRE_NAME");
                  int status = Integer.parseInt(rs.getString("total_qty"));
                if(status>0){
                     lbl_status.setText("Available");
                }
                else{
                lbl_status.setText("Not Available");}
                lbl_BookName.setText(namee);
                lbl_authorname.setText(author);
                lbl_genreshow.setText(genre);
                byte [] img = rs.getBytes("image");
               ImageIcon image = new ImageIcon(img);
                Image im = image.getImage();
                Image myImg = im.getScaledInstance( 250, 500 , Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                jLabel_Image_1.setImagen(newImage);
               
            }
            else{
                JOptionPane.showMessageDialog(null, "no data");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
            
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        searchbybook = new app.bolivia.swing.JCTextField();
        rSMaterialButtonRectangle1 = new rojerusan.RSMaterialButtonRectangle();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lbl_BookName = new javax.swing.JLabel();
        lbl_author = new javax.swing.JLabel();
        lbl_genre = new javax.swing.JLabel();
        lbl_genreshow = new javax.swing.JLabel();
        lbl_genre1 = new javax.swing.JLabel();
        lbl_status = new javax.swing.JLabel();
        lbl_authorname = new javax.swing.JLabel();
        jLabel_Image_1 = new rojerusan.RSPanelImage();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-search-book-100.png"))); // NOI18N
        jLabel12.setText("Search Book");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 330, 110));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 120, 360, 5));

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Search A Book");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 160, 30));

        jPanel7.setBackground(new java.awt.Color(255, 51, 51));

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel14.setText("Back");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel14)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        searchbybook.setBackground(new java.awt.Color(204, 204, 204));
        searchbybook.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        searchbybook.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        searchbybook.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        searchbybook.setPlaceholder("Search by Book name");
        searchbybook.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        searchbybook.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchbybookFocusLost(evt);
            }
        });
        searchbybook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbybookActionPerformed(evt);
            }
        });
        searchbybook.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchbybookKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchbybookKeyReleased(evt);
            }
        });
        jPanel1.add(searchbybook, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 350, 40));

        rSMaterialButtonRectangle1.setBackground(new java.awt.Color(0, 204, 153));
        rSMaterialButtonRectangle1.setText("Search");
        rSMaterialButtonRectangle1.setContentAreaFilled(false);
        rSMaterialButtonRectangle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle1ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonRectangle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, 150, 60));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 250));

        jPanel8.setBackground(new java.awt.Color(255, 51, 51));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 35)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("X");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(255, 51, 51));

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 35)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("X");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel5)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(0, 2, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 2, Short.MAX_VALUE)))
        );

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1680, 0, 130, 40));

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel6.setText("Book Name : ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 340, 270, -1));

        lbl_BookName.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        getContentPane().add(lbl_BookName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 340, 310, 40));

        lbl_author.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        lbl_author.setText("Author Name : ");
        getContentPane().add(lbl_author, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 410, 270, -1));

        lbl_genre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        lbl_genre.setText("Genre :");
        getContentPane().add(lbl_genre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 470, 120, -1));

        lbl_genreshow.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        getContentPane().add(lbl_genreshow, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 470, 310, 40));

        lbl_genre1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        lbl_genre1.setText("Status:");
        getContentPane().add(lbl_genre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 530, 110, -1));

        lbl_status.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        getContentPane().add(lbl_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 530, 310, 40));

        lbl_authorname.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        getContentPane().add(lbl_authorname, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 410, 310, 40));

        javax.swing.GroupLayout jLabel_Image_1Layout = new javax.swing.GroupLayout(jLabel_Image_1);
        jLabel_Image_1.setLayout(jLabel_Image_1Layout);
        jLabel_Image_1Layout.setHorizontalGroup(
            jLabel_Image_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jLabel_Image_1Layout.setVerticalGroup(
            jLabel_Image_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 270, Short.MAX_VALUE)
        );

        getContentPane().add(jLabel_Image_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 300, 250, 270));

        setSize(new java.awt.Dimension(954, 617));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        student_dashboard StudentDashboard = new student_dashboard(id1);
        StudentDashboard.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel14MouseClicked

    private void searchbybookFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchbybookFocusLost

    }//GEN-LAST:event_searchbybookFocusLost

    private void searchbybookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbybookActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchbybookActionPerformed

    private void searchbybookKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbybookKeyReleased
    }//GEN-LAST:event_searchbybookKeyReleased

    private void searchbybookKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbybookKeyPressed
        String s = searchbybook.getText();
        searchfilter(s);
       // mylist.setVisible(true);
    }//GEN-LAST:event_searchbybookKeyPressed

    private void rSMaterialButtonRectangle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle1ActionPerformed
       search();
    }//GEN-LAST:event_rSMaterialButtonRectangle1ActionPerformed
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(searchbookdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(searchbookdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(searchbookdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(searchbookdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new searchbookdetails(id1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private rojerusan.RSPanelImage jLabel_Image_1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lbl_BookName;
    private javax.swing.JLabel lbl_author;
    private javax.swing.JLabel lbl_authorname;
    private javax.swing.JLabel lbl_genre;
    private javax.swing.JLabel lbl_genre1;
    private javax.swing.JLabel lbl_genreshow;
    private javax.swing.JLabel lbl_status;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle1;
    private app.bolivia.swing.JCTextField searchbybook;
    // End of variables declaration//GEN-END:variables
}
