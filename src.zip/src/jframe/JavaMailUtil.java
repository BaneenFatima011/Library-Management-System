/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jframe;

import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/**
 *
 * @author BSP
 */
public class JavaMailUtil {
    public static void sendmail(String recepient) throws MessagingException
	{
            System.out.println("preparing to send email");
            Properties properties = new Properties();
             properties.put("mail.smtp.auth", "true");
	         properties.put("mail.smtp.starttls.enable","true");
	         properties.put("mail.smtp.host", "smtp.gmail.com");
	         properties.put("mail.smtp.port", "587");
	String myaccountemail = "rummana1010@gmail.com";
	      String password = "frkvxsbscdqpnbdf";
	      String host = "smtp.gmail.com";
	      String port = "587";
	      Session session = Session.getInstance(properties, new Authenticator(){
	                                 protected PasswordAuthentication getPasswordAuthentication() {
	                                    return new PasswordAuthentication(myaccountemail, password);
	                                 }});
	     
	         Message msg = prepareDefaulterMessage(session,myaccountemail,recepient);
                 Transport.send(msg);
                 System.out.println("message sent");
	   }
     public static void newstudentsmail(String recepient,String name,int id,String pass) throws MessagingException
	{
            System.out.println("preparing to send email");
            Properties properties = new Properties();
             properties.put("mail.smtp.auth", "true");
	         properties.put("mail.smtp.starttls.enable","true");
	         properties.put("mail.smtp.host", "smtp.gmail.com");
	         properties.put("mail.smtp.port", "587");
              String myaccountemail = "rummana1010@gmail.com";
	      String password = "frkvxsbscdqpnbdf";
	      String host = "smtp.gmail.com";
	      String port = "587";
	      Session session = Session.getInstance(properties, new Authenticator(){
	                                 protected PasswordAuthentication getPasswordAuthentication() {
	                                    return new PasswordAuthentication(myaccountemail, password);
	                                 }});
	     
	         Message msg = prepareMessage(session,myaccountemail,recepient,name,id,pass);
                 Transport.send(msg);
                 System.out.println("message sent");
	   } 
    private static Message prepareMessage(Session session,String myaccountemail,String recepient,String name,int id,String password){
    try{
    Message msg= new MimeMessage(session);
    msg.setFrom(new InternetAddress(myaccountemail));
	         msg.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
	         msg.setSubject("Library Account Information");
	         msg.setText("Dear,"+name+"\n" +
"\n" +
"I am writing to inform you that you have been added to our library system and your account is now active. You now have access to a wide range of resources that will help you in your studies.\n" +
"\n" +
"Your library login information is as follows:\n" +
"\n" +
"ID:"+ id +"\n" +
"Password:" +password + "\n" +
"\n" +
"Please note that this is a temporary password, and we recommend that you change it as soon as possible to ensure the security of your account. You can do this by logging in to your account and navigating to the settings section.\n" +
"\n" +
"With your library account, you can browse our catalog, search for books, and reserve materials online. You can also access electronic resources such as e-books and academic journals.\n" +
"\n" +
"If you have any questions or concerns about your library account or need help accessing resources, please do not hesitate to contact us. We are happy to assist you.\n" +
"\n" +
"Thank you for using our library services, and we look forward to supporting you in your academic pursuits.\n" +
"\n" +
"Best regards"+
"\n" +
"Fast NUCES");
	         return msg;
    }
    catch(Exception ex){
                         System.out.println("error");
    }
        return null;
    
    }
    private static Message prepareDefaulterMessage(Session session,String myaccountemail,String recepient){
    try{
    Message msg= new MimeMessage(session);
    msg.setFrom(new InternetAddress(myaccountemail));
	         msg.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
	         msg.setSubject("Overdue Library Book Notice");
	         msg.setText("Dear Student,\n" +
"\n" +
"I am writing to remind you that the book you borrowed from the library is currently overdue. According to our records, the due date for this book was [Due Date], and it has not been returned to the library yet.\n" +
"\n" +
"As a library member, it is your responsibility to return borrowed materials on time so that other students may have access to them. We understand that sometimes circumstances may arise that make it difficult to return books on time. However, we kindly ask that you return the book as soon as possible to avoid any further overdue charges.\n" +
"\n" +
"Please note that you may be charged a late fee of per day until the book is returned. If you have lost the book or it has been damaged, please let us know as soon as possible so that we can work together to find a solution.\n" +
"\n" +
"If you have any questions or concerns regarding this matter, please do not hesitate to contact us. We are here to help you in any way we can.\n" +
"\n" +
"Thank you for your attention to this matter, and we hope to hear from you soon.\n" +
"\n" +
"Best regards,\n" +
"\n" +
"[Fast NUCES]");
	         return msg;
    }
    catch(Exception ex){
                         System.out.println("error");
    }
        return null;
    
    }

}
