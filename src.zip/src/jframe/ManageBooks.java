
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframe;

import jaco.mp3.player.MP3Player;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author sunil
 */

public class ManageBooks extends javax.swing.JFrame {
     public void publicAddActionPerformed(ActionEvent evt) {
   rSMaterialButtonRectangle1ActionPerformed(evt);
}   
     
     public void publicAddActionPerformedUpdate(ActionEvent evt) {
   rSMaterialButtonRectangle2ActionPerformed(evt);
}    
      public void publicAddActionPerformedDelete(ActionEvent evt) {
   rSMaterialButtonRectangle3ActionPerformed(evt);
}    
    public static String getMessage(){
    return message;
} 
 public JTextField getBookIdField() {
       
    return txt_bookId;
}
 public JTextField getBooknameField() {
       
   return txt_bookName;
}
  public JTextField getAuthnameField() {
       
    return txt_authorName;
}
  public void setFile(File file) {
        this.f = file;
        // If needed, you can update any UI elements or perform additional actions here
    }
  public File getfile(){
  return f;}
public JTextField getAuthId() {
    return author_id;
}
public JTextField getQuantityField() {
    return quantitylbl2;
}
public JTextField getNationalityField(){
return nationalitylbl;}

public JComboBox getGenreField(){
return Genre;}

public JButton getAddButton() {
    return rSMaterialButtonRectangle1;
}
public JButton getDeleteButton() {
    return rSMaterialButtonRectangle3;
}
public JButton getUpdateButton() {
    return rSMaterialButtonRectangle2;
}





 public static String message;
     File selectedFile=null;
    File f = null;
    static int num=200;
    String path = null;
    private ImageIcon format=null;
    String fname = null;
    int s=0;
    byte[] pimage = null;
    String bookName,author,status,genre,bookId;
    int quantity;
    DefaultTableModel model;
    public ManageBooks() {
        initComponents();
        setBookDetailsToTable();
        errorlabel.setVisible(false);
        errorlabel1.setVisible(false);    
        
        Action printAction = new AbstractAction("Delete") {
            @Override
            public void actionPerformed(ActionEvent e){
               shortcut();
            }
        };
     String key= "Delete";  
    
    }
    public void shortcut(){
       if (deleteBook()== true) {
      int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
           if(response == JOptionPane.YES_OPTION){
               
            JOptionPane.showMessageDialog(this, "Book Deleted");
            clearTable();
            setBookDetailsToTable();
           }
           else{
               
           }
 }
else{
            JOptionPane.showMessageDialog(this, "Book Deletion Failed");
        }
    }
    //to set the book details into the table
    public void setBookDetailsToTable(){
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select B.BOOK_ID,B.BOOK_NAME,A.AUTHOR_ID,A.NATIONALITY,A.FIRST_NAME,G.GENRE_NAME,B.TOTAL_QTY from HR1.BOOKS B JOIN HR1.AUTHORS A ON A.AUTHOR_ID=B.AUTHOR_ID JOIN HR1.GENRE G ON G.GENRE_ID=B.GENRE_ID");
            while(rs.next()){
                String bookId = rs.getString("BOOK_ID");
                String bookName = rs.getString("BOOK_NAME");
                String author = rs.getString("FIRST_NAME");
                int quantity = rs.getInt("TOTAL_QTY");
                String genre = rs.getString("GENRE_NAME");
                String author_id=rs.getString("AUTHOR_ID");
                 String NATIONALITY=rs.getString("NATIONALITY");
               
                Object[] obj = {bookId,bookName,author_id,author,NATIONALITY,quantity,genre};
                model =(DefaultTableModel) tbl_bookDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    
    //to add book to book_details table
   public boolean addBook() {
       int id=0;
    boolean isAdded = false;
    String book=txt_bookId.getText();
    bookId = "B" + txt_bookId.getText();
    bookName = txt_bookName.getText();
    author = txt_authorName.getText();
    status = author_id.getText();
    quantity = Integer.parseInt(quantitylbl2.getText());
    genre = (String) Genre.getSelectedItem();
    String nationality = nationalitylbl.getText();
   
    try {
        Class.forName("oracle.jdbc.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);
 
     
 
        // Check if the book with the same ID already exists
        String checkQuery = "SELECT COUNT(*) FROM HR1.BOOKS WHERE BOOK_ID = ?";
        try (PreparedStatement checkStmt = con.prepareStatement(checkQuery)) {
            checkStmt.setString(1, bookId);
            try (ResultSet resultSet = checkStmt.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    // Book ID already exists, show dialog and return
                    JOptionPane.showMessageDialog(null, "Book ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
        }

        
        /*String checkQuery1 = "SELECT *  FROM HR1.GENRE ";
        PreparedStatement checkStmt = con.prepareStatement(checkQuery1);
        
        
       ResultSet rs=checkStmt.executeQuery();
       String s,s2;
       
       while(rs.next()){
     s=rs.getString("Genre_id");
      s2=  rs.getString("GENRE_NAME");
            
     if(genre==s2){
     System.out.println(s);*/
     
     
       
    
       
        // Book ID doesn't exist, proceed to add the new book
        InputStream is = new FileInputStream(f);
       
        String call = "{call HR1.ADD_BOOK(?, ?, ?, ?, ?, ?, ?, ? )}";

        try (CallableStatement stmt = con.prepareCall(call)) {
            stmt.setString(1, bookId); // P_BOOK_ID
            stmt.setString(2, bookName); // P_BOOK_NAME
            stmt.setString(3, status); // P_AUTHOR
            stmt.setInt(4, quantity); // P_QUANTITY
            stmt.setString(5, genre); // P_GENRE
            stmt.setBlob(6, is); // P_IS (replace yourBlobObject with your actual Blob data)
            stmt.setString(7, author); // PARAM1
            stmt.setString(8, nationality); // NUM

            // Execute the tored procedure
            stmt.execute();

            System.out.println("Stored procedure executed successfully!");
            isAdded = true;
            if(isAdded){
      String quer = "INSERT INTO HR1.BOOK_COPIES VALUES (?,?,?)";
        PreparedStatement pst = con.prepareStatement(quer);
      for (int i=0;i<quantity;i++){
      
    
              pst.setString(1, book+id);
              pst.setString(2, bookId);
              pst.setString(3,"In");
              pst.executeUpdate();
              id++;
      
      
      }
    
    
    }

        }
        
        
     
        } catch (Exception e) {
        e.printStackTrace();
        isAdded = false;
    }
    
    return isAdded;
   }
   
    //to update book details
    
    public boolean updateBook(){
      boolean isUpdated = false;
       // System.out.print("Image path- " +path);
//        System.out.print("Image Name- "+f.getName());
//        File f = new File(path);
        bookId = txt_bookId.getText();
        bookName = txt_bookName.getText();
        author = txt_authorName.getText();
        
        status = author_id.getText();
        quantity = Integer.parseInt(quantitylbl2.getText());
        genre=(String) Genre.getSelectedItem();
         String nationality = nationalitylbl.getText();
        try {
             Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
       
            
             String sql1="SELECT GENRE_ID FROM HR1.GENRE WHERE GENRE_NAME=?";
            String sql = "update HR1.BOOKS set book_name = ? ,total_qty = ?, genre_id = ?, author_id=?where book_id = ?";
           String sql2="update HR1.AUTHORS set first_name = ?,nationality=? where author_id = ?";
            PreparedStatement pst1 = con.prepareStatement(sql2);
             PreparedStatement pst2 = con.prepareStatement(sql1);
              String genreId=null;
             pst2.setString(1, genre);
             ResultSet rs = pst2.executeQuery();
             if (rs.next()) {
    genreId = rs.getString("GENRE_ID");
   
}
            PreparedStatement pst = con.prepareStatement(sql);
           
           pst.setString(5, bookId);
             pst.setString(4, status);
            pst.setString(1, bookName);
            pst.setInt(2, quantity);
            pst.setString(3, genreId);
           
             pst1.setString(1, author);
                pst1.setString(3, status);
                   pst1.setString(2, nationality);
                 int r_c=pst1.executeUpdate();
            int rowCount = pst.executeUpdate();
           
            if (rowCount > 0 && r_c >0) {
                isUpdated = true;
              
                       
            }else{
                isUpdated = false;
            }
        } catch (Exception e ) {
            e.printStackTrace();
        }
       
        
        return isUpdated;
    }
    
    //method to delete book detail
    public boolean deleteBook() {
    boolean isDeleted = false;
    bookId = txt_bookId.getText();

    try {
        Class.forName("oracle.jdbc.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);

        // Check if the book is issued
        String checkIssuedSql = "SELECT * FROM HR1.ISSUED_BOOKS WHERE BOOK_ID = ? AND STATUS = 'OUT'";
        try (PreparedStatement checkIssuedStmt = con.prepareStatement(checkIssuedSql)) {
            checkIssuedStmt.setString(1, bookId);
            try (ResultSet issuedResultSet = checkIssuedStmt.executeQuery()) {
                if (issuedResultSet.next()) {
                    JOptionPane.showMessageDialog(this, "Book cannot be deleted as it is issued.");
                    return false;
                }
            }
        }

        // Delete from BOOK_COPIES
        String deleteCopiesSql = "DELETE FROM HR1.BOOK_COPIES WHERE BOOK_ID = ?";
        try (PreparedStatement deleteCopiesStmt = con.prepareStatement(deleteCopiesSql)) {
            deleteCopiesStmt.setString(1, bookId);
            int rowsDeletedFromCopies = deleteCopiesStmt.executeUpdate();

            // Delete from BOOKS
            String deleteBookSql = "DELETE FROM HR1.BOOKS WHERE BOOK_ID = ?";
            try (PreparedStatement deleteBookStmt = con.prepareStatement(deleteBookSql)) {
                deleteBookStmt.setString(1, bookId);
                int rowsDeletedFromBooks = deleteBookStmt.executeUpdate();

                if (rowsDeletedFromBooks > 0 && rowsDeletedFromCopies > 0) {
                    isDeleted = true;
                    txt_bookId.setEnabled(true);
                    author_id.setEnabled(true);
                    clearFields();
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return isDeleted;
}

    
    //method to clear table
    
    public void clearTable(){
        DefaultTableModel model = (DefaultTableModel) tbl_bookDetails.getModel();
        model.setRowCount(0);
    }
    public void clearFields(){
        author_id.setEnabled(true);
        txt_bookId.setEnabled(true);
       txt_bookId.setText("");
      txt_bookName.setText("");
       txt_authorName.setText("");
       author_id.setText("");
       nationalitylbl.setText("");
Genre.setSelectedItem("");
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        managebookspanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_bookDetails = new rojeru_san.complementos.RSTableMetro();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        rSMaterialButtonRectangle1 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle2 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle3 = new rojerusan.RSMaterialButtonRectangle();
        searchbybook1 = new app.bolivia.swing.JCTextField();
        jLabel12 = new javax.swing.JLabel();
        rSMaterialButtonRectangle5 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle6 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle7 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle8 = new rojerusan.RSMaterialButtonRectangle();
        searchCriteriaDropdown = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        btnsave = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txt_bookId = new app.bolivia.swing.JCTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_bookName = new app.bolivia.swing.JCTextField();
        txt_authorName = new app.bolivia.swing.JCTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        author_id = new app.bolivia.swing.JCTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        imagePath = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        nationalitylbl = new app.bolivia.swing.JCTextField();
        rSMaterialButtonRectangle4 = new rojerusan.RSMaterialButtonRectangle();
        lblimage = new rojerusan.RSPanelImage();
        errorlabel = new java.awt.Label();
        errorlabel1 = new java.awt.Label();
        Genre = new javax.swing.JComboBox<>();
        quantitylbl1 = new app.bolivia.swing.JCTextField();
        quantitylbl2 = new app.bolivia.swing.JCTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        managebookspanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("X");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        managebookspanel.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 0, 130, 40));

        tbl_bookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book Id", "Name", "Author Id", "Author", "Author's Nationality", "Quantity", "Genre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_bookDetails.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tbl_bookDetails.setColorBackgoundHead(new java.awt.Color(0, 102, 102));
        tbl_bookDetails.setColorBordeFilas(new java.awt.Color(0, 102, 102));
        tbl_bookDetails.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        tbl_bookDetails.setColorFilasForeground1(new java.awt.Color(0, 0, 0));
        tbl_bookDetails.setColorFilasForeground2(new java.awt.Color(0, 0, 0));
        tbl_bookDetails.setColorSelBackgound(new java.awt.Color(204, 255, 204));
        tbl_bookDetails.setColorSelForeground(new java.awt.Color(0, 0, 0));
        tbl_bookDetails.setDragEnabled(true);
        tbl_bookDetails.setFont(new java.awt.Font("Yu Gothic UI Light", 0, 25)); // NOI18N
        tbl_bookDetails.setFuenteFilas(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        tbl_bookDetails.setFuenteFilasSelect(new java.awt.Font("Yu Gothic UI", 1, 20)); // NOI18N
        tbl_bookDetails.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 20)); // NOI18N
        tbl_bookDetails.setRowHeight(40);
        tbl_bookDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_bookDetailsMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbl_bookDetailsMouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_bookDetails);

        managebookspanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 820, 320));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 102));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-books-100.png"))); // NOI18N
        jLabel3.setText("  Manage Books");
        managebookspanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 370, -1));

        jPanel5.setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        managebookspanel.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 410, 5));

        rSMaterialButtonRectangle1.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle1.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle1.setText("Add");
        rSMaterialButtonRectangle1.setContentAreaFilled(false);
        rSMaterialButtonRectangle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle1ActionPerformed(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, 180, -1));

        rSMaterialButtonRectangle2.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle2.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle2.setText("Update");
        rSMaterialButtonRectangle2.setContentAreaFilled(false);
        rSMaterialButtonRectangle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle2ActionPerformed(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 610, 180, -1));

        rSMaterialButtonRectangle3.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle3.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle3.setText("delete");
        rSMaterialButtonRectangle3.setContentAreaFilled(false);
        rSMaterialButtonRectangle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle3ActionPerformed(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 610, 170, -1));

        searchbybook1.setBackground(new java.awt.Color(204, 204, 204));
        searchbybook1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        searchbybook1.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        searchbybook1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        searchbybook1.setPlaceholder("Search by Book name");
        searchbybook1.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        searchbybook1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchbybook1FocusLost(evt);
            }
        });
        searchbybook1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbybook1ActionPerformed(evt);
            }
        });
        searchbybook1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchbybook1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchbybook1KeyReleased(evt);
            }
        });
        managebookspanel.add(searchbybook1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 360, 40));

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel12.setText("Search A Book");
        managebookspanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 160, 30));

        rSMaterialButtonRectangle5.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle5.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle5.setText("Search");
        rSMaterialButtonRectangle5.setContentAreaFilled(false);
        rSMaterialButtonRectangle5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle5ActionPerformed(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle5, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 160, 150, 60));

        rSMaterialButtonRectangle6.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle6.setText("ALL RECORDS");
        rSMaterialButtonRectangle6.setContentAreaFilled(false);
        rSMaterialButtonRectangle6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonRectangle6MouseClicked(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 190, 140, 60));

        rSMaterialButtonRectangle7.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle7.setText("ALL RECORDS");
        rSMaterialButtonRectangle7.setContentAreaFilled(false);
        rSMaterialButtonRectangle7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonRectangle7MouseClicked(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 190, 140, 60));

        rSMaterialButtonRectangle8.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle8.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle8.setText("all records");
        rSMaterialButtonRectangle8.setContentAreaFilled(false);
        rSMaterialButtonRectangle8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonRectangle8MouseClicked(evt);
            }
        });
        managebookspanel.add(rSMaterialButtonRectangle8, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 160, 140, 60));

        searchCriteriaDropdown.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Book Id", "Name", "Genre ", "Author id", "Author " }));
        managebookspanel.add(searchCriteriaDropdown, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 230, 170, -1));

        getContentPane().add(managebookspanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 880, 720));

        btnsave.setBackground(new java.awt.Color(0, 102, 102));
        btnsave.setAutoscrolls(true);
        btnsave.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Enter Book ISBN");
        btnsave.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 180, 30));

        txt_bookId.setBackground(new java.awt.Color(0, 102, 102));
        txt_bookId.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_bookId.setForeground(new java.awt.Color(255, 255, 255));
        txt_bookId.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_bookId.setPhColor(new java.awt.Color(255, 255, 255));
        txt_bookId.setPlaceholder("Enter Book Id  ...");
        txt_bookId.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_bookIdFocusLost(evt);
            }
        });
        txt_bookId.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txt_bookIdMousePressed(evt);
            }
        });
        txt_bookId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_bookIdKeyPressed(evt);
            }
        });
        btnsave.add(txt_bookId, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 260, 40));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        btnsave.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 60, 50));

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Enter Book Name : ");
        btnsave.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 210, 30));

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        btnsave.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 40, 50));

        txt_bookName.setBackground(new java.awt.Color(0, 102, 102));
        txt_bookName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_bookName.setForeground(new java.awt.Color(255, 255, 255));
        txt_bookName.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_bookName.setPhColor(new java.awt.Color(255, 255, 255));
        txt_bookName.setPlaceholder("Enter Book Name :  ...");
        txt_bookName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_bookNameFocusLost(evt);
            }
        });
        txt_bookName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bookNameActionPerformed(evt);
            }
        });
        txt_bookName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_bookNameKeyPressed(evt);
            }
        });
        btnsave.add(txt_bookName, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 260, 40));

        txt_authorName.setBackground(new java.awt.Color(0, 102, 102));
        txt_authorName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_authorName.setForeground(new java.awt.Color(255, 255, 255));
        txt_authorName.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_authorName.setPhColor(new java.awt.Color(255, 255, 255));
        txt_authorName.setPlaceholder("Author Name ...");
        txt_authorName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_authorNameFocusLost(evt);
            }
        });
        txt_authorName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_authorNameActionPerformed(evt);
            }
        });
        btnsave.add(txt_authorName, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 270, 40));

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Author Name");
        btnsave.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 250, 30));

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        btnsave.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 640, 60, 50));

        author_id.setBackground(new java.awt.Color(0, 102, 102));
        author_id.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        author_id.setForeground(new java.awt.Color(255, 255, 255));
        author_id.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        author_id.setPhColor(new java.awt.Color(255, 255, 255));
        author_id.setPlaceholder("Author id ...");
        author_id.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                author_idFocusLost(evt);
            }
        });
        author_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                author_idActionPerformed(evt);
            }
        });
        btnsave.add(author_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, 270, 40));

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Unit_26px.png"))); // NOI18N
        btnsave.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 60, 50));

        jPanel4.setBackground(new java.awt.Color(255, 51, 51));

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel2.setText("Back");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnsave.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 50));

        jLabel13.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Author's ORCID id:");
        btnsave.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 310, 30));

        imagePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imagePathActionPerformed(evt);
            }
        });
        btnsave.add(imagePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 780, 210, 30));

        jLabel8.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-book-50.png"))); // NOI18N
        btnsave.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, 50, 60));

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Genre:");
        btnsave.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 310, 30));

        jLabel15.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newicons/icons8-book-50.png"))); // NOI18N
        btnsave.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, 60));

        jLabel16.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Author's Nationality");
        btnsave.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 310, 30));

        nationalitylbl.setBackground(new java.awt.Color(0, 102, 102));
        nationalitylbl.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        nationalitylbl.setForeground(new java.awt.Color(255, 255, 255));
        nationalitylbl.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        nationalitylbl.setPhColor(new java.awt.Color(255, 255, 255));
        nationalitylbl.setPlaceholder("Author's Nationality ...");
        nationalitylbl.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                nationalitylblFocusLost(evt);
            }
        });
        nationalitylbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nationalitylblActionPerformed(evt);
            }
        });
        btnsave.add(nationalitylbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 640, 270, 40));

        rSMaterialButtonRectangle4.setBackground(new java.awt.Color(0, 153, 102));
        rSMaterialButtonRectangle4.setText("Choose Image");
        rSMaterialButtonRectangle4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle4ActionPerformed(evt);
            }
        });
        btnsave.add(rSMaterialButtonRectangle4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 690, 150, 60));

        javax.swing.GroupLayout lblimageLayout = new javax.swing.GroupLayout(lblimage);
        lblimage.setLayout(lblimageLayout);
        lblimageLayout.setHorizontalGroup(
            lblimageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        lblimageLayout.setVerticalGroup(
            lblimageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        btnsave.add(lblimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 570, -1, -1));

        errorlabel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        errorlabel.setForeground(new java.awt.Color(255, 0, 0));
        btnsave.add(errorlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 240, 30));

        errorlabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        errorlabel1.setForeground(new java.awt.Color(255, 0, 0));
        btnsave.add(errorlabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 260, 30));

        populateComboBoxFromDatabase(Genre);
        Genre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenreActionPerformed(evt);
            }
        });
        btnsave.add(Genre, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 490, 250, -1));

        quantitylbl1.setBackground(new java.awt.Color(0, 102, 102));
        quantitylbl1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        quantitylbl1.setForeground(new java.awt.Color(255, 255, 255));
        quantitylbl1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        quantitylbl1.setPhColor(new java.awt.Color(255, 255, 255));
        quantitylbl1.setPlaceholder("quantity");
        quantitylbl1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                quantitylbl1FocusLost(evt);
            }
        });
        quantitylbl1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantitylbl1ActionPerformed(evt);
            }
        });
        btnsave.add(quantitylbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 270, 0));

        quantitylbl2.setBackground(new java.awt.Color(0, 102, 102));
        quantitylbl2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        quantitylbl2.setForeground(new java.awt.Color(255, 255, 255));
        quantitylbl2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        quantitylbl2.setPhColor(new java.awt.Color(255, 255, 255));
        quantitylbl2.setPlaceholder("quantity");
        quantitylbl2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                quantitylbl2FocusLost(evt);
            }
        });
        quantitylbl2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantitylbl2ActionPerformed(evt);
            }
        });
        btnsave.add(quantitylbl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 570, 270, 40));

        jLabel17.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Quantity:");
        btnsave.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 540, 310, 30));

        jLabel18.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        btnsave.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 60, 50));

        jScrollPane1.setViewportView(btnsave);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 350, 770));

        setSize(new java.awt.Dimension(1254, 760));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
private void populateComboBoxFromDatabase(JComboBox<String> comboBox)  {
    try {
         Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            
        String query = "SELECT GENRE_NAME FROM HR1.GENRE"; 
        try (PreparedStatement statement = con.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
           comboBox.removeAllItems();

           
            while (resultSet.next()) {
                String item = resultSet.getString("GENRE_NAME"); 
                comboBox.addItem(item);
            }
             comboBox.addItem("Add New Genre");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
     System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked
     
    private void tbl_bookDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_bookDetailsMouseClicked
        int rowNo = tbl_bookDetails.getSelectedRow();
        TableModel model = tbl_bookDetails.getModel();
        txt_bookId.setText(model.getValueAt(rowNo, 0).toString());
        txt_bookId.setEnabled(false);
        txt_bookName.setText(model.getValueAt(rowNo, 1).toString());
        txt_authorName.setText(model.getValueAt(rowNo, 3).toString());
        author_id.setText(model.getValueAt(rowNo, 2).toString());
       quantitylbl2.setText(model.getValueAt(rowNo, 5).toString());
        author_id.setEnabled(false);

        nationalitylbl.setText(model.getValueAt(rowNo,4).toString());
    }//GEN-LAST:event_tbl_bookDetailsMouseClicked

    private void txt_bookIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_bookIdFocusLost

    }//GEN-LAST:event_txt_bookIdFocusLost

    private void txt_bookNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_bookNameFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bookNameFocusLost

    private void txt_bookNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bookNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bookNameActionPerformed

    private void txt_authorNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_authorNameFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_authorNameFocusLost

    private void txt_authorNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_authorNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_authorNameActionPerformed

    private void author_idFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_author_idFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_author_idFocusLost

    private void author_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_author_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_author_idActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        HomePage home = new HomePage();
        home.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    private void imagePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imagePathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_imagePathActionPerformed

    private void nationalitylblFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nationalitylblFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_nationalitylblFocusLost

    private void nationalitylblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nationalitylblActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nationalitylblActionPerformed

    private void rSMaterialButtonRectangle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle1ActionPerformed
       if(txt_bookName.getText().isEmpty()||txt_authorName.getText().isEmpty()||author_id.getText().isEmpty()||txt_bookId.getText().isEmpty()||quantitylbl2.getText().isEmpty()||nationalitylbl.getText().isEmpty()){
        JOptionPane.showMessageDialog(this, "Fill all the fields");
        message="Fill all the fields";
       } else if (Pattern.matches(".*\\d+.*", txt_bookName.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter alphabets only");
    message = "Warning! Enter alphabets only";
} else if (Pattern.matches(".*[a-zA-Z]+.*", txt_bookId.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter numbers only");
    message = "Warning! Enter numbers only";
}
       
       else{
         if (addBook() == true) {                 
            ProgressBar p = new ProgressBar();
                p.setVisible(true);
                this.setVisible(true);
            JOptionPane.showMessageDialog(this, "Book Added");
             message="Book Added";
          
            clearFields();
            clearTable();
            setBookDetailsToTable();
        }else{
            JOptionPane.showMessageDialog(this, "Book Id Already exsist");
             message="Book Id Already exsist";
        }
       }
    }//GEN-LAST:event_rSMaterialButtonRectangle1ActionPerformed

    private void rSMaterialButtonRectangle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle2ActionPerformed
       if(txt_bookName.getText().isEmpty()||txt_authorName.getText().isEmpty()||author_id.getText().isEmpty()||txt_bookId.getText().isEmpty()||quantitylbl2.getText().isEmpty()||nationalitylbl.getText().isEmpty()){
        JOptionPane.showMessageDialog(this, "Fill all the fields");
        message="Fill all the fields";
       } 
      else if (Pattern.matches(".*\\d+.*", txt_bookName.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter alphabets only");
    message = "Warning! Enter alphabets only";
} else{
         
              if (updateBook() == true) {
            JOptionPane.showMessageDialog(this, "Book Updated");
            clearFields();
            clearTable();
            setBookDetailsToTable();
             message="Book Updated";
        }else{
            JOptionPane.showMessageDialog(this, "Book Updation Failed");
             clearFields();
             message="Book Updation Failed";
        }}
    
    }//GEN-LAST:event_rSMaterialButtonRectangle2ActionPerformed
 
    private void rSMaterialButtonRectangle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle3ActionPerformed
        if(txt_bookName.getText().isEmpty()||txt_authorName.getText().isEmpty()||author_id.getText().isEmpty()||txt_bookId.getText().isEmpty()||quantitylbl2.getText().isEmpty()||nationalitylbl.getText().isEmpty()){
        JOptionPane.showMessageDialog(this, "Fill all the fields");
        message="Fill all the fields";
       }
     else if (Pattern.matches(".*\\d+.*", txt_bookName.getText())) {
    JOptionPane.showMessageDialog(this, "Warning! Enter alphabets only");
    message = "Warning! Enter alphabets only";
} 
        
        else{
        
        if (deleteBook()== true) {
      int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
           if(response == JOptionPane.YES_OPTION){
               
            JOptionPane.showMessageDialog(this, "Book Deleted");
            message="Book Deleted";
            clearFields();
            clearTable();
            setBookDetailsToTable();
           }
           else{
               
           }
 }
else{
           clearFields();
            JOptionPane.showMessageDialog(this, "Book Deletion Failed");
             message="Book Deletion Failed";
        } }
    }//GEN-LAST:event_rSMaterialButtonRectangle3ActionPerformed
public void search(String searchTerm) {
    try {
        Class.forName("oracle.jdbc.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String username = "system";
        String password = "abc123";
        Connection con = DriverManager.getConnection(url, username, password);
        

        // Get the selected search criteria from the dropdown
           String searchBy = ((String) searchCriteriaDropdown.getSelectedItem()).trim();

        String query = "SELECT B.BOOK_ID, B.BOOK_NAME, A.AUTHOR_ID, A.NATIONALITY, A.FIRST_NAME, G.GENRE_NAME, B.TOTAL_QTY FROM HR1.BOOKS B JOIN HR1.AUTHORS A ON A.AUTHOR_ID = B.AUTHOR_ID JOIN HR1.GENRE G ON G.GENRE_ID = B.GENRE_ID WHERE ";
System.out.println(searchBy);
        switch (searchBy) {
            case "Book Id":
                query += " B.BOOK_ID  LIKE ?";  
                break;
            case "Name":
                query += " B.BOOK_NAME  LIKE ?";
                break;
            case "Author id":
                query += " A.AUTHOR_ID  LIKE ?";
                break;
            case "Genre":
                query += " G.GENRE_NAME  LIKE ?";
                break;
            case "Author":
                query += " A.FIRST_NAME  LIKE ?";
                break;
            default:
                // Handle invalid searchBy value
                System.out.println("Invalid searchBy value");
                return;
        }

        try  {
            
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, "%"+searchTerm+"%");
            ResultSet rs = stmt.executeQuery();
              model.setRowCount(0);
             
System.out.println("works"+searchTerm);
            while (rs.next()) {
               System.out.print("in rs"); 
                String bookId = rs.getString("BOOK_ID");
                String bookName = rs.getString("BOOK_NAME");
                String author = rs.getString("FIRST_NAME");
                int quantity = rs.getInt("TOTAL_QTY");
                String genre = rs.getString("GENRE_NAME");
                String author_id = rs.getString("AUTHOR_ID");
                String nationality = rs.getString("NATIONALITY");

                Object[] obj = {bookId, bookName, author_id, author, nationality, quantity, genre};
               
                model.addRow(obj);
            }
            
        
    } catch (Exception e) {
        e.printStackTrace();
    }}
    catch (Exception e) {
        e.printStackTrace();
    }
}

    private void txt_bookIdMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_bookIdMousePressed
       
    }//GEN-LAST:event_txt_bookIdMousePressed

    private void txt_bookIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bookIdKeyPressed
       char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            errorlabel.setText("Warning!Enter digits only");
            errorlabel.setVisible(true);
        }    
        else{
            errorlabel.setVisible(false);

        }
    }//GEN-LAST:event_txt_bookIdKeyPressed

    private void txt_bookNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bookNameKeyPressed
       char c = evt.getKeyChar();
            if(Character.isDigit(c)){
            errorlabel1.setText("Warning!Enter alphabets only");
            errorlabel1.setVisible(true);
        }  
            else{
                         errorlabel1.setVisible(false);
   
            }
    }//GEN-LAST:event_txt_bookNameKeyPressed

    private void rSMaterialButtonRectangle4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle4ActionPerformed
 JFileChooser fc = new JFileChooser();
    FileNameExtensionFilter fwf = new FileNameExtensionFilter("PNG, JPG, JPEG Images", "png", "jpg", "jpeg");
    fc.addChoosableFileFilter(fwf);

    int load = fc.showOpenDialog(null);

    if (load == JFileChooser.APPROVE_OPTION) {
        selectedFile = fc.getSelectedFile();
        f = selectedFile;}   
    }//GEN-LAST:event_rSMaterialButtonRectangle4ActionPerformed

    private void searchbybook1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchbybook1FocusLost

    }//GEN-LAST:event_searchbybook1FocusLost

    private void searchbybook1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbybook1ActionPerformed
    }//GEN-LAST:event_searchbybook1ActionPerformed

    private void searchbybook1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbybook1KeyPressed
        
        
    }//GEN-LAST:event_searchbybook1KeyPressed

    private void searchbybook1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbybook1KeyReleased

    }//GEN-LAST:event_searchbybook1KeyReleased

    private void rSMaterialButtonRectangle5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle5ActionPerformed

      
        search(searchbybook1.getText());
        
    }//GEN-LAST:event_rSMaterialButtonRectangle5ActionPerformed

    private void rSMaterialButtonRectangle6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle6MouseClicked
        
    }//GEN-LAST:event_rSMaterialButtonRectangle6MouseClicked

    private void rSMaterialButtonRectangle7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle7MouseClicked

        
    }//GEN-LAST:event_rSMaterialButtonRectangle7MouseClicked

    private void rSMaterialButtonRectangle8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle8MouseClicked
        clearTable();
        setBookDetailsToTable();
    }//GEN-LAST:event_rSMaterialButtonRectangle8MouseClicked

    private void GenreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenreActionPerformed

Genre.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
     JComboBox<String> combo = (JComboBox<String>) e.getSource();
        String selectedGenre = (String) combo.getSelectedItem();

        if ("Add New Genre".equals(selectedGenre)) {
            // Prompt the user to enter genre details
            JPanel panel = new JPanel();
            JTextField genreIdField = new JTextField(10);
            JTextField genreNameField = new JTextField(10);

            panel.add(new JLabel("Genre ID:"));
            panel.add(genreIdField);
            panel.add(new JLabel("Genre Name:"));
            panel.add(genreNameField);

            int result = JOptionPane.showConfirmDialog(null, panel, "Enter Genre Details",
                    JOptionPane.OK_CANCEL_OPTION);

            // Check if the user clicked OK
            if (result == JOptionPane.OK_OPTION) {
                String genreId = genreIdField.getText();
                String genreName = genreNameField.getText();

                // Check if the user entered valid values
                if (!genreId.isEmpty() && !genreName.isEmpty()) {
                    // Check if the genre already exists in the combo box
                    if (!genreExists(combo, genreName)) {
                        // Add the new genre to the combo box
                        combo.addItem(genreName);
                        // Select the new genre in the combo box
                        combo.setSelectedItem(genreName);

                        // Add the new genre to the database
                        addGenreToDatabase(genreId, genreName);
                        
                    } else {
                        // Genre already exists, show a message or handle accordingly
                        JOptionPane.showMessageDialog(null, "Genre already exists!");
                    }
                } else {
                    // User entered empty values, reset selection to the previous value
                    combo.setSelectedItem(combo.getItemAt(0)); // Assuming the first item is not "Add New Genre"
                }
            }
        }
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_GenreActionPerformed

    private void tbl_bookDetailsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_bookDetailsMouseReleased
        // TODO add your handling code here:
            
        
           
    }//GEN-LAST:event_tbl_bookDetailsMouseReleased

    private void quantitylbl1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_quantitylbl1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_quantitylbl1FocusLost

    private void quantitylbl1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantitylbl1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quantitylbl1ActionPerformed

    private void quantitylbl2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_quantitylbl2FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_quantitylbl2FocusLost

    private void quantitylbl2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantitylbl2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quantitylbl2ActionPerformed
private boolean genreExists(JComboBox<String> comboBox, String genreName) {
    for (int i = 0; i < comboBox.getItemCount(); i++) {
        if (genreName.equals(comboBox.getItemAt(i))) {
            return true;
        }
    }
    return false;
}

// Method to add the new genre to the database
private void addGenreToDatabase(String genreId, String genreName) {
    // Implement your database insertion logic here
    // Use JDBC to connect to the database and execute the INSERT statement
    // Example:
    try {
         Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String username = "system";
            String password = "abc123";
             Connection con = DriverManager.getConnection(url,username,password);
            
        String query = "INSERT INTO HR1.GENRE VALUES (?, ?)"; 
   
    // try (Connection connection = DriverManager.getConnection("jdbc:your_database_url", "your_username", "your_password")) {
    //     String query = "INSERT INTO your_genre_table (genre_id, genre_name) VALUES (?, ?)";
       try(PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, genreId);
            statement.setString(2, genreName);
           statement.executeUpdate();
         
       
     } catch (SQLException ex) {
         ex.printStackTrace();
    // }}
}}      catch (ClassNotFoundException ex) {
            Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);
        }}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageBooks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Genre;
    private app.bolivia.swing.JCTextField author_id;
    private javax.swing.JPanel btnsave;
    private java.awt.Label errorlabel;
    private java.awt.Label errorlabel1;
    private javax.swing.JTextField imagePath;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private rojerusan.RSPanelImage lblimage;
    public javax.swing.JPanel managebookspanel;
    private app.bolivia.swing.JCTextField nationalitylbl;
    private app.bolivia.swing.JCTextField quantitylbl1;
    private app.bolivia.swing.JCTextField quantitylbl2;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle1;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle2;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle3;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle4;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle5;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle6;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle7;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle8;
    private javax.swing.JComboBox<String> searchCriteriaDropdown;
    private app.bolivia.swing.JCTextField searchbybook1;
    private rojeru_san.complementos.RSTableMetro tbl_bookDetails;
    private app.bolivia.swing.JCTextField txt_authorName;
    private app.bolivia.swing.JCTextField txt_bookId;
    private app.bolivia.swing.JCTextField txt_bookName;
    // End of variables declaration//GEN-END:variables
}

